
package toba.data;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import toba.business.User;
import toba.data.DBtool;

public class UserDB {
    public static void insert(User user){
        EntityManager ent = DBtool.getEmFactory().createEntityManager();
        EntityTransaction tran = ent.getTransaction();
        tran.begin();
        try{
            ent.persist(user);
            tran.commit();
        }catch(Exception e){
            System.out.println(e);
            tran.rollback();
        }finally{
            ent.close();
        }
    }
    
    public static void update(User user){
        EntityManager ent = DBtool.getEmFactory().createEntityManager();
        EntityTransaction tran = ent.getTransaction();
        tran.begin();
        try{
            ent.persist(user);
            tran.commit();
        }catch(Exception e){
            System.out.println(e);
            tran.rollback();
        }finally{
            ent.close();
        }
    }
}
